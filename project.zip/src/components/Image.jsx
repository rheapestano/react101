import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { Container, Row, Col } from 'reactstrap';

class Image extends PureComponent {
    static propTypes = {
        src: PropTypes.string.isRequired,
     }

    render() {
        const { image } = this.props;

        return (
            <Col>
                <img src={image.src} />
            </Col>
        );
    }
        
}

export default Image;