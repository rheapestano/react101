import { reducer as formReducer } from 'redux-form';
import Images from './Images/reducers';

export default {
    form: formReducer,
    Images,
};