import Images from './Images/sagas';

export default [
    Images,
];